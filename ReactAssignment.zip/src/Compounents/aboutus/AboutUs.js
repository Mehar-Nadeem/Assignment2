import "./AboutUs.css"
import image1 from "../../assests/image/img_about_us.png"


export default function AboutUs() {
  return (
    <>

      <div className="container">
        <div class="row">
          <div className="col-lg-8 col-sm-12">
            <img className="image-fluid imagew" src={image1} alt="" />
          </div>
          <div className="col-lg-4 col-sm-12 ">
            <div className="aboutus1">
              <h2>About us</h2>
              <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Voluptate provident reprehenderit,
                nulla adipisci pariatur dolor culpa ex maxime cumque nemo Lorem ipsum dolor sit amet ipsum 
                dolor sit ametipsum dolor sit amet culpa ex maxime cumque nemo Lorem culpa ex maxime cumque 
                nemo Lorem .!</p>
                <button className="btn btn-dark">More on Our History </button>
            </div>

          </div>

        </div>
      </div>



    </>

  )
}
