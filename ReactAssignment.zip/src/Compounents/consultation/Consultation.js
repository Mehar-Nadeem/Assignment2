import "./Consultation.css"

export default function Consultation() {
  return (
    <>
    <div className="container-fluid backgrounImage my-5">
        <div class="row cstmdesign">
            <div className="col-lg-8">
            <h1 className="text-white">Free Consultation with Expectional Quality </h1>
            <h4 className="text-white">Just on Call Away: <a href="callto:+923046202752">+923046202752</a></h4>
            </div>
            <div className="col-lg-4">

                <button className="btn text-white btn-outline-primary">Get Your Consultation</button>
            </div>
        </div>

    </div>
    </>
  )
}
