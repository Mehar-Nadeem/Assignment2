import "./Reputation.css"

import { BsHeadphones } from "react-icons/bs";
import { BsPenFill } from "react-icons/bs";


function Reputation() {
    return (
        <>
            <div className="container mt-5 mb-5">
                <h1 className="text-center">Our Reputation</h1>
                <div class="row dreputed">

                    <div className="col-3  repute">
                        <h4><BsHeadphones /></h4>
                        <h4>Best Services</h4>
                        <p className="edittext" >Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, hic.</p >
                    </div>
                    <div className="col-3  repute">
                        <h4><BsHeadphones /></h4>
                        <h4>Best Teams</h4>
                        <p className="edittext">Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, hic.</p >

                    </div>
                    <div className="col-3  repute">
                        <h4><BsPenFill /></h4>
                        <h4>Best Designs</h4>
                        <p className="edittext" >Lorem ipsum dolor sit amet consectetur adipisicing elit. Suscipit, hic.</p  >

                    </div>
                </div>
            </div>


        </>
    );

}
export default Reputation;


