import "./HeroSection.css";
import { BsArrowRight } from "react-icons/bs";
import { BsArrowLeft } from "react-icons/bs";


function HeroSection() {
    return (
        <>
            <div className="container-fluid image1">
                <div className="container">
                    <div class="row">
                        <div className="col-12">
                          
                                <h1 style={{ padding: "100px" }} className="pt-5">Builing Things  <br /> is our Mission</h1>
                                <div className="feature">
                                    <h4>Features Projects</h4>
                                    <p>The National Universty of Architecture</p>
                                    <div class="row p-2 ">
                                    <div className="col-5 m-1 bg-dark">
                                    <h3><a style={{color:"white"}} href="#"><BsArrowLeft/></a></h3>
                                    </div>
                                    <div className="col-5 m-1  bg-dark">
                                        
                                        <h3><a style={{color:"white"}} href="#"><BsArrowRight/></a></h3>
                                    </div>
                                    </div>
                                </div>
                               
                                    
 
                        </div>
                    </div>
                </div>
            </div>
        </>
    );

}
export default HeroSection;
