import React from 'react'
import afaqAli from '../../assests/image/img_mrParkinstons.png'
import buliding from '../../assests/image/img_oregano_height.png'
import car from '../../assests/image/img_wildstone.png'
import bus from '../../assests/image/img_wish_stone_building.png'
import './ProjectsStyles.css'
export default function Projects() {
    return (
        <div>
            <div className='container'>
                <div className='row mt-3'>
                    <h2>Projects</h2>
                    <div className='col-md-4'>
                            <ul className='listSetting'>
                                <li className='listSetting1'>All</li>
                                <li className='listSetting2'>Commercial</li>
                                <li className='listSetting3'>Residental</li>
                                <li className='listSetting4'>Others</li>
                            </ul>
                    </div>
                    <div className='col-md-8'>
                        <div className='row p-3'>
                            <div className='col-md-6'>
                                <div class="card bg-dark text-white">
                                    <img src={afaqAli} class="card-img" alt="logo" />
                                    <div class="card-img-overlay" id="crdSettings">
                                        <h6 class="card-title">Wish Stone Buildin</h6>
                                        <p class="card-text">2972 Westheimer Rd. Santa Ana, Illinois</p>
                                    </div>
                                </div>
                            </div>
                            <div className='col-md-6'>
                                <div class="card bg-dark text-white">
                                    <img src={buliding} class="card-img" alt="..." />
                                    <div class="card-img-overlay" id="crdSettings">
                                    <h6 class="card-title">Wish Stone Buildin</h6>
                                        <p class="card-text">2972 Westheimer Rd. Santa Ana, Illinois</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div className='row p-3'>
                            <div className='col-md-6'>
                                <div class="card bg-dark text-white">
                                    <img src={bus} class="card-img" alt="..." />
                                    <div class="card-img-overlay" id="crdSettings">
                                    <h6 class="card-title">Wish Stone Buildin</h6>
                                        <p class="card-text">2972 Westheimer Rd. Santa Ana, Illinois</p>
                                    </div>
                                </div>
                            </div>
                            <div className='col-md-6'>
                                <div class="card bg-dark text-white">
                                    <img src={car} class="card-img" alt="..." />
                                    <div class="card-img-overlay" id="crdSettings">
                                    <h6 class="card-title">Wish Stone Buildin</h6>
                                        <p class="card-text">2972 Westheimer Rd. Santa Ana, Illinois</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    )
}
