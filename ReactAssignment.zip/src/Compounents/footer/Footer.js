import React from 'react'
import logo from "../../assests/image/logo.png"

import { BsFacebook } from "react-icons/bs";
import { BsLinkedin } from "react-icons/bs";
import { BsTwitter } from "react-icons/bs";


export default function Footer() {
    return (
        <>
            <div className="container">
                <div className="row">
                    <div className="col-lg-6 col-sm-12 p-5">
                        <h6 className='my-3 text-primary'><b>Address :</b> <span style={{ color: "grey" }}>Jaboka Post Office Khas Tehsil District Okara.</span> </h6>
                        <h6 className='my-3 text-primary'><b>Phone :</b> <a style={{ color: "grey" }} href="callto:+923046202752">+923046202752</a> </h6>
                        <h6 className='my-3 text-primary'><b>Email : </b> <a style={{ color: "grey" }} href="mailto:muhammadnadeem9083@gmail.com">muhammadnadeem9083@gmail.com</a> </h6>
                        <img src={logo} alt="logo" />
                        <a className="navbar-brand textlogo  mx-3 pb-5" href="#"> <b>TheBOX</b> </a>


                    </div>
                    <div className="col-lg-6 col-sm-12  ">
                        <h6 className='my-3 text-primary  pt-5'><b>Newsletter</b></h6>

                        <div className="input-group ">
                            <input type="email" className="form-control" placeholder="Your Email Here " aria-label="Recipient's username" aria-describedby="basic-addon2" />
                            <div className="input-group-append butn">
                                <span className="input-group-text " id="basic-addon2">Subscribe</span>
                            </div>
                        </div>


                        <h6 className='my-3 text-primary  '><b>Social:</b></h6>

                        <a className='px-3' href="#"><BsFacebook /></a>
                        <a className='px-3' href="#"><BsLinkedin /></a>
                        <a className='px-3' href="#"><BsTwitter /></a>

                    </div>


                </div>

            </div>
            <div className="container-fluid bg-primary">
                <div className="container">
                    <div class="row">


                        <p className='p-3 text-white'>TheBox Company @ 2022  All Rights Reserved</p>



                    </div>
                </div>
            </div>


        </>
    )
}
